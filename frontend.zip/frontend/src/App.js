import { ImageUpload } from "./home";

function App() {
  return <ImageUpload />;
}

export default App;
